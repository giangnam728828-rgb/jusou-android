import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';
import { Clipboard } from '@capacitor/clipboard';

// 在安卓 APK 中用系统 Custom Tabs 打开搜索结果；网页版本仍使用原有新标签逻辑。
if (Capacitor.isNativePlatform()) {
  window.JUSOU_NATIVE_OPEN = async (url) => {
    const parsed = new URL(url);
    if (!['https:', 'http:'].includes(parsed.protocol)) return;
    await Browser.open({ url: parsed.href, presentationStyle: 'popover' });
  };
}

// Android 原生剪贴板读取，避免 WebView Clipboard API 权限/手势限制。
if (Capacitor.isNativePlatform()) {
  window.JUSOU_NATIVE_CLIPBOARD_READ = async () => {
    const result = await Clipboard.read();
    return result && typeof result.value === 'string' ? result.value : '';
  };
}
