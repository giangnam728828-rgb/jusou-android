import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';

// 在安卓 APK 中用系统 Custom Tabs 打开搜索结果；网页版本仍使用原有新标签逻辑。
if (Capacitor.isNativePlatform()) {
  window.JUSOU_NATIVE_OPEN = async (url) => {
    const parsed = new URL(url);
    if (!['https:', 'http:'].includes(parsed.protocol)) return;
    await Browser.open({ url: parsed.href, presentationStyle: 'popover' });
  };
}
