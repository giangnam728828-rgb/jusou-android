# 聚搜 · 一站搜全网（安卓 APK 项目）

这是基于原始 `index.html` 制作的 Capacitor 安卓项目，保留原来的搜索站点、分类、收藏、搜索历史、自定义站点、默认搜索引擎和本地备份功能。

## 本次处理

- 将原网页放入 Vite 构建流程，供 Capacitor 打包。
- 添加 Capacitor Browser 桥接：APK 内点击搜索站点时，使用 Android Custom Tabs 打开外部搜索结果，避免 Android WebView 忽略 `target="_blank"`。
- 加入「聚搜」专属图标与启动图资源。
- 保留现有 `localStorage` 数据逻辑；应用数据保存在本机应用 WebView 存储中。卸载应用或清除应用数据可能会清掉这些数据，建议使用应用内“备份与恢复”保存备份。
- 修复搜索历史里的“清空”入口被 CSS 隐藏的问题。
- 加强备份导入检查：限制站点数量、名称和 URL 长度，只接受 HTTP/HTTPS 地址，并校验颜色、分类和收藏项目。

## 最快拿到 APK：使用 GitHub Actions 云构建

本运行环境没有安装 Android SDK、Gradle，也没有配置安卓签名环境，因此这里不能直接产出并验证 APK。项目已包含自动构建工作流；上传到 GitHub 后会在云端构建调试版 APK。

1. 解压项目 ZIP。
2. 在 GitHub 新建一个空仓库，例如 `jusou-android`。
3. 把解压后的**项目内所有文件**上传到仓库根目录（确保 `.github/workflows/build-apk.yml` 也上传了）。也可以在电脑安装 Git 后执行：

   ```bash
   git init
   git add .
   git commit -m "Initial Jusou Android app"
   git branch -M main
   git remote add origin 你的GitHub仓库地址
   git push -u origin main
   ```

4. 打开仓库的 **Actions** 页面，进入 **Build Jusou Android APK** 工作流。
5. 等待工作流完成，打开本次运行页面底部的 **Artifacts**，下载 `jusou-android-debug-apk`。
6. 解压下载的文件，里面的 `app-debug.apk` 就是可安装的安卓调试版 APK。把它传到 vivo 手机上安装；安卓可能会要求允许该来源安装应用。

> 这是用于个人安装测试的 debug APK，不是应用商店发布包。不要把私钥或签名密码提交到仓库。如果以后要正式发布，再配置自己的 release 签名。

## 本地构建（需要电脑）

需要 Node.js 22、JDK 21、Android Studio/Android SDK，以及可用的 Android SDK 平台与构建工具。然后在项目目录运行：

```bash
npm install
npm run build
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
```

用 Android Studio 打开 `android` 目录，等待 Gradle 同步后选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。APK 通常位于 `android/app/build/outputs/apk/debug/app-debug.apk`。

## 后续修改网页

编辑根目录 `index.html` 后重新构建并同步：

```bash
npm run build
npx cap sync android
```

然后重新构建 APK。`app-bridge.js` 是原生外部链接桥接，不建议删除。

## 已知说明

- 搜索仍需联网；此项目没有实现离线搜索。
- 搜索站点的页面和登录行为由各网站自身控制，个别网站可能会要求登录、限制访问或改变搜索 URL。
- 本项目没有云同步；收藏、历史、自定义站点等保存在本机。跨设备迁移可用内置备份与恢复。
- 自动构建的 APK 需要在真实 vivo 安卓设备上进一步检查启动、返回、外部浏览器跳转和不同搜索网站的兼容性；此环境无法代替真机测试。
